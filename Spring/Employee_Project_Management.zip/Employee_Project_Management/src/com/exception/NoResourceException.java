package com.exception;

public class NoResourceException extends Exception {
	
	public NoResourceException(){
		super("No More Resource Required");
	}

}
