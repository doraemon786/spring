package com.exception;

public class SkillMismatchException extends Exception {
	
	public SkillMismatchException(){
		super("Skill Mismatch");
	}

}
